import os
import json,pathlib,struct,collections
root=pathlib.Path(os.environ.get('XL_RESEARCH_OUTPUT', './analysis-output'));j=json.load(open(root/'features.json'))
for r in j:
 b=(root/(r['sha256']+'.rl2')).read_bytes();p=r['sections']['objects']['offset'];objs=[]
 try:
  for i in range(r['sections']['objects']['count']):
   typ,id,ct,mt,rt,fl=b[p:p+6];start=p;p+=79+(r['game_version']>37)
   p+={0:0,1:64,3:12}[mt]
   p+={0:0,1:20,2:10,4:0,5:0,9:8,12:0,13:4,14:4,16:0,17:12}[ct]
   payload=p
   p+={0:0,1:72,2:9,3:0,4:9,5:9,6:72,7:9,8:0,11:29+(r['version']>=18)+(r['version']>=19),12:44+4*(r['version']>22)+(r['version']>21)+(r['version']>=19),13:44+(r['version']>=19)}[rt]
   o=dict(index=i,type=typ,id=id,control=ct,render=rt)
   if rt==13:o['sound']=b[payload:payload+40].split(b'\0')[0].decode('latin1')
   objs.append(o)
  r['object_records']=objs;r['objects_end']=p;r['objects_end_matches_walls']=p==r['sections']['walls']['offset']
 except Exception as e:print('ERROR',r['path'],i,ct,mt,rt,repr(e))
(root/'features.json').write_text(json.dumps(j,indent=2))
print('object_end_matches',collections.Counter(r.get('objects_end_matches_walls') for r in j))
for rt in [11,12,13]:
 rows=[r for r in j if any(o['render']==rt for o in r.get('object_records',[]))]
 print('render',rt,'levels',len(rows),'count',sum(sum(o['render']==rt for o in r['object_records']) for r in rows))
 for r in rows: print(r['path'].split('::')[-1],sum(o['render']==rt for o in r['object_records']))
