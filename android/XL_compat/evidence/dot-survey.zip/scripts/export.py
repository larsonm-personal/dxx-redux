import os
import json,csv,pathlib,re,collections
p=pathlib.Path(os.environ.get('XL_RESEARCH_OUTPUT', './analysis-output'));j=json.load(open(p/'features.json'));inv=json.load(open(p/'inventory.json'))
desc={e['path'].lower():e['text'] for e in inv['entries'] if 'text' in e}
with open(p/'xl-levels.csv','w') as f:
 w=csv.writer(f);w.writerow(['mission','descriptor','level','archive_member','sha256','level_version','game_version','vertices','segments','walls','objects','wall_triggers','object_triggers','equipment_generators','geometry_boundary_matches','object_boundary_matches'])
 for r in j:
  h,level=r['path'].rsplit('::',1);d=h[:-4]+'.mn2';txt=desc.get(d.lower(),'');name=next((ln.split('=',1)[1].strip() for ln in txt.splitlines() if re.match(r'^(?:name|xname|zname|d2x-name)\s*=',ln,re.I)),'UNRESOLVED')
  r['mission_name']=name;r['descriptor_path']=d
  w.writerow([name,d,level,r['path'],r['sha256'],r['version'],r['game_version'],r['vertices'],r['segments'],r['sections']['walls']['count'],r['sections']['objects']['count'],len(r['triggers']),len(r.get('object_triggers',[])),r['sections'].get('equipment',{}).get('count',0),r['geometry_end_matches_game'],r.get('objects_end_matches_walls','unparsed')])
(p/'features.json').write_text(json.dumps(j,indent=2))
print('mission names',len(set(r['mission_name'] for r in j)),collections.Counter(r['mission_name'] for r in j))
print('XL high wall refs',sum(r['high_wall_references']>0 for r in j));print('sound nautilus',[(x['index'],x['sound']) for r in j if r['path'].endswith('::nautilus.rl2') for x in r.get('object_records',[]) if x['render']==13][:8])
