import os
import json,struct,pathlib,collections
root=pathlib.Path(os.environ.get('XL_RESEARCH_OUTPUT', './analysis-output'))
def parse(r):
 b=(root/(r['sha256']+'.rl2')).read_bytes();v=r['version'];g=r['game_offset'];p=g+35
 sec={}
 for n in ['objects','walls','doors','triggers','links','control','robots','light_indices','light_deltas']+(['equipment'] if v>15 else []):
  sec[n]=dict(zip(['offset','count','size'],struct.unpack_from('<iii',b,p)));p+=12
 r['sections']=sec
 tr=[];s=sec['triggers'];p=s['offset']
 def trigger(obj=False):
  nonlocal p
  t=b[p];p+=1
  f=struct.unpack_from('<H' if obj else '<B',b,p)[0];p+=2 if obj else 1
  n=b[p];p+=2;val,time=struct.unpack_from('<ii',b,p);p+=8
  targets=struct.unpack_from('<20h',b,p);p+=40
  return dict(type=t,flags=f,links=n,value=val,time=time,segments=list(targets[:n]),sides=list(targets[10:10+n]))
 if s['count'] and p>=0:
  tr=[trigger() for _ in range(s['count'])]
 r['triggers']=tr
 if r['game_version']>=33 and p>=0:
  n=struct.unpack_from('<i',b,p)[0];p+=4
  assert 0<=n<10000,n
  r['object_triggers']=[trigger(True) for _ in range(n)]
 walls=[];s=sec['walls'];p=s['offset'];ws=24+(r['game_version']>=37)
 for i in range(s['count']):
  k=p+i*ws
  walls.append(dict(type=b[k+16],flags=struct.unpack_from('<H' if ws==25 else '<B',b,k+17)[0],cloak=b[k+ws-1]))
 r['wall_types']=dict(collections.Counter(x['type'] for x in walls));r['nonzero_cloak']=dict(collections.Counter(x['cloak'] for x in walls if x['cloak']))
 p=r['mine_offset']+5+r['vertices']*12
 highwalls=[];owners=collections.Counter();groups=collections.Counter()
 for i in range(r['segments']):
  owners[b[p]]+=1;groups[b[p+1]]+=1;p+=2
  flags=b[p];p+=1
  children=[]
  for k in range(6):
   if flags&(1<<k):children.append(struct.unpack_from('<h',b,p)[0]);p+=2
   else:children.append(-1)
  p+=16
  flags=b[p];p+=1;wall=[]
  for k in range(6):
   if flags&(1<<k):
    z=struct.unpack_from('<H' if v>=13 else '<B',b,p)[0];p+=2 if v>=13 else 1;wall.append(z)
    if z>=255 and z!=65535:highwalls.append(z)
   else:wall.append(65535)
  for k in range(6):
   if children[k]==-1 or wall[k]!=65535:
    t=struct.unpack_from('<H',b,p)[0];p+=2
    if t&0x8000:p+=2
    p+=24
 r['high_wall_references']=len(highwalls);r['max_wall_reference']=max(highwalls,default=None)
 r['owners']=dict(owners);r['groups']=dict(groups)
 seg=[]
 for i in range(r['segments']):
  f,prod,val,flags=struct.unpack_from('<BBBB',b,p);p+=4
  props=0;damage=(0,0)
  if v>20:props=b[p];damage=struct.unpack_from('<hh',b,p+1);p+=5
  p+=4;seg.append((f,props,*damage))
 r['segment_functions']=dict(collections.Counter(x[0] for x in seg));r['segment_properties']=dict(collections.Counter(x[1] for x in seg));r['damage_segments']=[dict(index=i,shield=x[2],energy=x[3]) for i,x in enumerate(seg) if x[2] or x[3]]
 r['color_start']=p
 # Color tables: vertices, segment sides, textures (910)
 for name,count,floatver in [('vertex_colors',r['vertices'],14),('side_colors',r['segments']*6,13),('texture_colors',910,15)]:
  size=25 if v<=floatver else 13;colored=0;active=0
  for i in range(count):
   c=struct.unpack_from('<ddd' if size==25 else '<iii',b,p+1);active+=b[p]!=0;colored+=len(set(c))>1;p+=size
  r[name]=dict(count=count,active=active,non_gray=colored)
 r['geometry_end']=p;r['geometry_end_matches_game']=p==g
 return r
j=json.load(open(root/'inventory.json'));rows=[]
for r in j['levels']:
 if r['version']>8:
  try: rows.append(parse(r))
  except Exception as e: print('ERROR',r['path'],repr(e))
(root/'features.json').write_text(json.dumps(rows,indent=2))
for r in rows:
 print(r['path'].split('::')[-1],r['version'],r['vertices'],r['segments'],'wall',r['sections']['walls']['count'],'trig',dict(collections.Counter(t['type'] for t in r['triggers'])),'objtrig',len(r.get('object_triggers',[])),'func',r['segment_functions'],'props',r['segment_properties'],'damage',len(r['damage_segments']),'equip',r['sections'].get('equipment',{}).get('count'),'geometry',r['geometry_end_matches_game'])
