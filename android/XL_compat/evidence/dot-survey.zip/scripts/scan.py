import os
import sys, pathlib, struct, json, hashlib, collections
import libarchive
root=pathlib.Path(os.environ['XL_ASSET_ROOT']) / 'missions'; out=pathlib.Path(os.environ.get('XL_RESEARCH_OUTPUT', './analysis-output'))
out.mkdir(parents=True, exist_ok=True)
rows=[]; entries=[]; errors=[]
def inspect(b,path):
 if b[:4]==b'LVLP':
  v,mo,go=struct.unpack_from('<iii',b,4)
  r=dict(path=path,sha256=hashlib.sha256(b).hexdigest(),size=len(b),version=v,mine_offset=mo,game_offset=go)
  if 0<mo<len(b)-5:r.update(zip(['vertices','segments'],struct.unpack_from('<HH',b,mo+1)))
  if 0<go<len(b)-4:r['game_version']=struct.unpack_from('<H',b,go+2)[0]
  rows.append(r)
  if v>8:(out/(r['sha256']+'.rl2')).write_bytes(b)
 elif b[:3] in (b'DHF',b'D2X'):
  entries.append(dict(path=path,signature=b[:3].decode(),size=len(b)))
  p=3
  while p<len(b):
   if p+17>len(b):raise ValueError('short hog')
   n=b[p:p+13].split(b'\0')[0].decode('latin1'); sz=struct.unpack_from('<i',b,p+13)[0];p+=17
   if sz<0:n=b[p:p+256].split(b'\0')[0].decode('latin1');p+=256;sz=-sz
   if p+sz>len(b):raise ValueError('hog size')
   inspect(b[p:p+sz],path+'::'+n);p+=sz
 elif path.lower().endswith(('.mn2','.msn')):
  entries.append(dict(path=path,text=b.decode('latin1')))
 elif path.lower().endswith(('.clr','.hxm','.ham','.pmh','.oof','.ase','.tga','.ogg')):
  entries.append(dict(path=path,size=len(b),signature=b[:8].hex()))
for a in sorted(root.rglob('*')):
 if not a.is_file():continue
 try:
  with libarchive.file_reader(str(a)) as ar:
   for e in ar:
    if pathlib.PurePosixPath(e.pathname).suffix.lower() not in ('.hog','.rl2','.rdl','.mn2','.msn','.clr','.hxm','.ham','.pmh','.oof','.ase','.tga','.ogg'):continue
    if e.size>300*1024*1024:errors.append([str(a),'oversize',e.pathname]);continue
    inspect(b''.join(e.get_blocks()),str(a.relative_to(root))+'::'+e.pathname)
 except Exception as e: errors.append([str(a),repr(e)])
(out/'inventory.json').write_text(json.dumps(dict(levels=rows,entries=entries,errors=errors),indent=2))
print('archives',len(list(root.rglob('*'))),'levels',len(rows),'versions',collections.Counter(r['version'] for r in rows),'errors',errors)
for r in rows:
 if r['version']>8:print(r['path'],r['version'],r.get('game_version'),r.get('vertices'),r.get('segments'))
