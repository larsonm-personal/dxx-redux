# D2X-XL compatibility: static mission evidence

Research date: 2026-10-24. This is static inspection, not runtime qualification.
No implementation changes, commits, pushes, or mission execution were performed.

## Provenance and exact scope

- Redux: larsonm-personal/dxx-redux, published cmake commit 1cadb4d3e5a39bd7fa08926df2e53725b1851b64
- Private authorized assets: larsonm-personal/dxx-redux-test-assets commit d9fbeaf6eb059fd4504308bfd6364734775b7cba
- Format reference: arbruijn/d2x-xl commit 2576a98b5de310e3ac7c9777df2677d1627b8bae
- Official linked DietfridMali/D2X-XL repository returned Repository not found; that target was not retried. The fork is a qualified format reference, not verification of current official 2.0 semantics
- Read repository AGENTS.md and .github/copilot-instructions.md. Neither Redux checkout had .agents/skills; workspace .agents was empty
- Inspected 131 mission archives, including 19 in missions/d2xxl_downloads. The scanner's printed archives=132 counts the directory as well; 131 is the file count
- Identified 2,464 level-member occurrences; this is not a count of mission descriptor entries, unique levels, or playable levels
- Identified 131 distinct XL payloads across 56 HOGs, all in missions/d2xxl_downloads/levelpack.7z
- XL level versions: 11:1, 15:46, 17:24, 18:2, 19:1, 21:1, 23:56. Game-data versions: 31, 33, 34, 35, 36, 40
- All 131 geometry parses ended exactly at the declared game-data offset. Object parsing matched the following wall section in 129/131 files
- xl-levels.csv records every XL payload's member path, descriptor mapping, SHA-256, format versions and table counts. One descriptor mapping (teleport.hog) is unresolved
- features.json contains observed decoded records and counters. Segment function values are raw serialized values: versions <=20 use the older combined function/property encoding. Do not interpret those raw values using the v21+ function enumeration
- Historical 59 unsupported advertised levels and this 131-payload inventory have different denominators. The new inventory includes HOG content outside previously admitted mission selections

## Ten engineering categories

### 1. Extended mission/container and level-format parsing

Observed: one D2X HOG, missions/diedel/playgdd3.hog, versus 527 DHF HOG occurrences; 48 descriptors use d2x-name. Crownpoint X is v11, Lunar Outpost Reloaded v18, and Sphere v23.

Current Redux: MissionAssetCatalog.kt readHog accepts DHF only; d2/main/gamesave.c accepts level versions 1-8. Extended HOG uses a 13-byte short name, signed size, and a 256-byte long name when the size is negative. These are format-reference semantics, supported by the inspected D2X payload.

Implication: load blocker. Add versioned decoding and explicit descriptor/container support; never only relax the version check. Tests: signed-size bounds, long names, truncated entries, v13 wall-width transition, v21 segment fields, and exact section endpoints. Safe fallback: explicit unsupported-format rejection.

### 2. Larger tables and wider references

Observed: 21 XL levels exceed 255 walls and use widened indices. D.I: Monolevel (dinter.rl2) has 1,888 walls, 1,857 objects and 246 wall triggers. Anthology has 1,130 walls, 1,279 objects and 103 wall triggers. Sphere L1 has 1,029 walls.

Current Redux: 9,000 segments, 36,000 vertices, 255 walls, 1,000 objects, 100 triggers. No inspected XL payload exceeds current geometry capacity; maximum is D.I: Monolevel at 6,744 segments and 19,257 vertices.

Implication: expand tables and references together with save/demo/network encodings, sentinels and metadata consumers. Do not truncate gameplay tables. Tests: wall indices 254/255/256, high object/trigger indices and save/restore. Uneasy4 is an already handled large-level/performance case, not evidence of a new unsupported geometry ceiling.

### 3. Stateful event graphs and object triggers

Observed wall triggers: 99 masters in 8 levels, 14 enable actions in 5, 19 disable actions in 3. There are 212 object triggers in 22 levels. D.I: Monolevel alone has 65 masters and 96 object triggers. Wall flags: 131 permanent records, 52 alternating, 34 autoplay.

Implication: finite event-system support rather than an assumed need for a general scripting language. Implement version-aware master values, scheduling, activation sources, enable/disable and persistence. Reference source changes master-value interpretation around game-data v39. Tests: a short dependency/master chain, delayed action, alternating execution, object destruction and save/reload. Fallback: do not qualify progression-dependent events as playable when ignored.

### 4. Teleports, boosts and authored navigation

Observed wall triggers: 108 teleports in 19 levels, 281 boosts in 15 and 20 spawn-setting actions in 6. Lunar Outpost Reloaded has 35 boosts. Speed! has 20 teleports and 54 boosts. Sphere L4 has 12 teleports, 6 boosts and 2 spawn-setting actions. Object-trigger teleports also occur.

Implication: preserve destination, orientation and velocity semantics; route analysis must understand traversal edges. Tests: transport between disconnected regions, orientation flags, collision after transport, respawn and deterministic replay. Ignoring a teleporter is not a safe generic gameplay fallback. Directed exit semantics are an upstream lead, not separately quantified by this scan. Coordination was not identified in the corpus.

### 5. Extended segment properties and environmental rules

Observed: 49 levels have extended functions/properties. D.I: Monolevel segment 2215 stores shield damage 3 and energy damage 5. Boiling Point L1 watrwrks.rl2 has 141 water-property segments and 251 blocked-property segments. Lunar Outpost Reloaded has 509 old-format blocked segments.

Implication: distinguish combined pre-v21 types from split function/property fields. Implement blocked traversal and environmental effects. Redux already implements repair-center shield replenishment, called from d2/main/object.c; repair centers are not wholly absent. Tests: old/new equivalent encodings, damage over time and traversal restrictions. Preview fallback may omit effects, but must disclose degradation and not silently open authored barriers.

### 6. Equipment generators and extended spawning

Observed: 53 equipment generators in 11 levels. Pumo Mines preliminary L1 has 2. Sphere L3/L4/secret have 2/7/6. All 7 Boiling Point levels contain generators, including canyon.rl2 with 14. Sphere L4 object triggers include countdown and robot-spawn actions.

Implication: extend station types, generated-item data, activation/replenishment and persistence while preserving classic matcen behavior. Tests: activation, repeated production, exhaustion and save/reload. Inert fallback requires explicit warning and proof that progression does not depend on the generator.

### 7. Authored wall opacity and colored walls

Observed type-8 colored walls: Crownpoint X 58, Lunar Outpost Reloaded 12, Glass House 126. Sphere L1 has authored opacity values 12, 15, 16 and 18 on ordinary wall records.

Current Redux already has classic cloaked walls and bitmap transparency. Remaining work is authored material semantics, not transparency from scratch. Preserve visibility, collision and projectile rules independently. Tests: fixed-opacity closed wall, colored wall and layered textures. Opaque fallback can preserve collision but alters visibility and targeting, so it is degraded behavior.

### 8. Colored lighting and extended light records

Observed non-gray colors: vertex tables in 124/131 levels, side tables in 58, texture tables in 129. Sphere L1 has 3,831 non-gray vertex records. The broad inventory contains 369 CLR members, including classic-format missions.

Implication: correctly consume versioned color tables even before rendering them. Separate embedded XL colors from CLR sidecars. Tests: floating/integer serialization transitions, light on/off and scalar-light fallback. Grayscale is often a defensible presentation fallback; incorrect byte skipping is not.

PPG Hall is a separate classic-format repair: historical evidence records a 10,000-target table, 8 bounded ranges and 231 missing targets. Do not relabel it as an XL-only requirement.

### 9. Particle, lightning and ambient-sound objects

Observed in 129 successfully decoded object sections: 330 particle objects across 35 levels, 151 lightning objects across 21, and 1,335 sound objects across 29. Warp Shockwave L4 nautilus.rl2 has 61 sound objects including flowing-water and steam. D.I: Monolevel has 297 sound objects.

Implication: variable-size decoding is a load prerequisite; rendering and audio can then degrade independently while retaining object IDs and trigger references. Tests: each version-dependent payload, enable/disable, looping sound cleanup and mission transitions. Effects are not automatically optional if they supply cues or participate in triggers.

### 10. Mission-scoped assets and custom game data

Observed broad-corpus occurrences: 877 HXM, 31 HAM, 1 PMH, 236 TGA, 14 OOF and 85 OGG members. These are neither unique assets nor exclusively XL requirements. Retained PO2 analysis identifies a full-HAM PMH with 84 weapon records and distinct player-model HXM payloads; those detailed PMH counts were historical evidence, not freshly decoded here.

Current Redux already supports substantial standard HXM/extra-HAM, texture and mission sound behavior. HMQ dispatch is present, so the older proposal to add HMQ is stale. Remaining work requires scoped precedence, count/reference validation, rollback and explicit alternate model/data support. Tests: custom mission A -> stock -> custom mission B, saves and failed overrides. Never alias PO2 PMH into the stock HAM path.

## Prioritization and useful test slices

1. Format admission and widened tables
2. Event, movement, segment and generator semantics
3. Material, lighting, effect and resource fidelity

The Apocalyptic Factor XL (15 v15 payloads) and D2-XL: Counterstrike! (30 v15 payloads) are promising initial format/color probes: their decoded wall triggers use classic types 0-13 and wall counts stay within 255. This does not establish playability or that lighting is their only remaining difference.

Sphere and Boiling Point provide broad multi-level gameplay coverage. D.I: Monolevel is a combined stress case better used after smaller fixtures work.

Existing test sources inspected, not executed: android/tests/test_upstream_compat.cpp, test_level_section_io.c, test_mission_descriptor_safe.c, test_d2_ham_validation.c, matcen and secret-origin fixtures, mod_renderer and mod_save, and D2X-XL texture/sound conversion tests.

## Exclusions and uncertainty

- Static inspection only. Geometry/object endpoint matches are structural evidence, not runtime verification or complete validation of every reference
- odyssee.zip: one nested HOG traversal stopped on a size-boundary mismatch. This is a research-parser limitation, not a demonstrated engine incompatibility
- Object parsing unresolved for missions/diedel/playgdxl.hog::playgdxl.rl2 and missions/single/boilpnt.hog::subzero.rl2. Their geometry/wall/trigger evidence remains available; object/effect counts exclude them
- The previous Belial L12 runtime campaign was not restarted. Nine player starts in retained evidence do not establish crash causality
- Trigger/matcen/secret-origin normalization, HAM/HXM tails, negative-light and empty-joint repairs remain legacy compatibility evidence unless separately tied to XL data
- No conclusions about newer official 2.0 hub persistence or newer non-cubic geometry are drawn from this v11-v23 corpus

## Source/file references

All Redux paths are relative to commit 1cadb4d3e5a39bd7fa08926df2e53725b1851b64:

- android/app/src/main/java/com/dxxredux/app/MissionAssetCatalog.kt:23 (DHF catalog)
- d2/main/gamesave.c:1586 (level envelope/version admission)
- d2/main/segment.h:46, wall.h:29, object.h:35, switch.h:30 (capacities/types)
- d2/main/segment.c:14 (classic segment2 layout)
- d2/main/object.c:2312 and fuelcen.c:716 (repair behavior)
- d2/main/songs.c:160,352 (HMQ dispatch)
- android/ai tool plans/security/mission_security_compatibility_followup_20261016.md (historical repair findings)
- game_data/mission_files/d2xxl_downloads/po2_compatibility_notes.md (historical PO2 measurements; contains stale present-tense capability claims)

Format reference paths at arbruijn/d2x-xl commit 2576a98b5de310e3ac7c9777df2677d1627b8bae:

- io/hogfile.cpp:70 (extended member headers)
- main/segment.cpp:154,182 (segment extras and geometry)
- main/side.cpp:1470,1532 (sides and widened wall indices)
- main/wall.cpp:1208 (wall records)
- main/trigger.cpp:1441 and include/trigger.h (trigger fields and actions)
- gameio/loadobjects.cpp:285,550 (section headers and object triggers)
- gameio/loadgeometry.cpp:396,735 (colors and geometry)
- objects/objectio.cpp:71 (variable object payloads)

Canonical reference URL form: https://github.com/arbruijn/d2x-xl/blob/2576a98b5de310e3ac7c9777df2677d1627b8bae/<path>
